import React from 'react';

const Home = () => {
    return (
        <div>
            <h1>Welcome to Fake News Detector</h1>
            <p>Learn how to identify fake news!</p>
        </div>
    );
};

export default Home;